# 维护与续作

本压缩包是完整课程的维护源文件，不含原始教材PDF、提取正文或原页截图。解压到独立目录后可重建网站。

1. 安装 `requirements.txt` 中的依赖。
2. 修改 `lessons/week-NN/day-NN.html` 中的课程片段，保持原文信息与补充解释的区分；同步修改 `citations/week-NN.json`。
3. 运行 `python3 scripts/build.py`，输出位于 `site/`。网页使用构建时生成的MathML，访客无需安装依赖。
4. 完整来源核查还需从自己持有的对应PDF重建 `evidence/{source_id}/NNNN.txt`，页序从1开始；随后运行 `python3 scripts/validate.py`。没有原文提取时，验证器不能代替来源核查。
5. 对改变的内容重新进行公式、引用、浏览器及手机视口检查，再更新 `progress.json`，不可直接沿用旧的completed标记。

`source_catalog.json` 是资料版本及章节目录；`source_inventory.json` 是全页清点的自动定位候选，只含页序、图表号和方程编号候选，不含原文段落。候选不等于已核实引用；课程使用的可靠位置以 `citation_index.json` 及逐包核查报告为准。

原始网站地址及 `articles/day-01.html` 至 `day-56.html` 保持不变。根目录的网站ZIP可独立部署；此维护包不是网站发布所必需的依赖。
